﻿namespace Cat_W14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_nama = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgv_tabel = new System.Windows.Forms.DataGridView();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.lb_coba = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_pemain = new System.Windows.Forms.ComboBox();
            this.cb_tipe = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tabel)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(45, 42);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(84, 25);
            this.lb_nama.TabIndex = 1;
            this.lb_nama.Text = "Team : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pemain : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Minute : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Tipe : ";
            // 
            // dgv_tabel
            // 
            this.dgv_tabel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_tabel.Location = new System.Drawing.Point(37, 245);
            this.dgv_tabel.Name = "dgv_tabel";
            this.dgv_tabel.RowHeadersWidth = 82;
            this.dgv_tabel.RowTemplate.Height = 33;
            this.dgv_tabel.Size = new System.Drawing.Size(1292, 645);
            this.dgv_tabel.TabIndex = 5;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(164, 42);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(335, 33);
            this.cb_team.TabIndex = 6;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // lb_coba
            // 
            this.lb_coba.AutoSize = true;
            this.lb_coba.Location = new System.Drawing.Point(738, 50);
            this.lb_coba.Name = "lb_coba";
            this.lb_coba.Size = new System.Drawing.Size(70, 25);
            this.lb_coba.TabIndex = 7;
            this.lb_coba.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(738, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "ini value member";
            // 
            // cb_pemain
            // 
            this.cb_pemain.FormattingEnabled = true;
            this.cb_pemain.Location = new System.Drawing.Point(164, 92);
            this.cb_pemain.Name = "cb_pemain";
            this.cb_pemain.Size = new System.Drawing.Size(335, 33);
            this.cb_pemain.TabIndex = 9;
            this.cb_pemain.SelectedIndexChanged += new System.EventHandler(this.cb_pemain_SelectedIndexChanged);
            // 
            // cb_tipe
            // 
            this.cb_tipe.FormattingEnabled = true;
            this.cb_tipe.Location = new System.Drawing.Point(164, 194);
            this.cb_tipe.Name = "cb_tipe";
            this.cb_tipe.Size = new System.Drawing.Size(335, 33);
            this.cb_tipe.TabIndex = 11;
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(164, 142);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(100, 31);
            this.tb_minute.TabIndex = 13;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(557, 185);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(117, 39);
            this.btn_add.TabIndex = 14;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1388, 661);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.cb_tipe);
            this.Controls.Add(this.cb_pemain);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_coba);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.dgv_tabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_nama);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tabel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgv_tabel;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label lb_coba;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_pemain;
        private System.Windows.Forms.ComboBox cb_tipe;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Button btn_add;
    }
}

