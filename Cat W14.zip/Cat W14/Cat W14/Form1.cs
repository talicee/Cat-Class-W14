﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Cat_W14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtteam = new DataTable();
        DataTable dtplayer = new DataTable();
        DataTable dtmatch = new DataTable();
        DataTable dttype = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection(
                $"server=localhost;" +
                $"uid=root;" +
                $"pwd=isbmantap;" +
                $"database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();

            string team = "select team_name, team_id from team;";
            sqlCommand = new MySqlCommand(team, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam);

            //for (int i = 0; i < dtteam.Rows.Count; i++)
            //{
            //    cb_team.Items.Add(dtteam.Rows[i][0].ToString());
            //}
            cb_team.SelectedIndex = -1;
            cb_team.DataSource = dtteam;
            cb_team.ValueMember = "team_id";
            cb_team.DisplayMember = "team_name";

            dttype.Columns.Add("Panjang");
            dttype.Columns.Add("Singkatan");

            dttype.Rows.Add("Goal", "GO");
            dttype.Rows.Add("Goal Penalty", "GP");
            dttype.Rows.Add("Own Goal", "GW");
            dttype.Rows.Add("Yellow Card", "CY");
            dttype.Rows.Add("Red Card", "CR");
            dttype.Rows.Add("Penalty Miss", "PM");

            cb_tipe.DataSource = dttype;
            cb_tipe.ValueMember = "Singkatan";
            cb_tipe.DisplayMember = "Panjang";
            cb_tipe.SelectedIndex = -1;

        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtplayer.Rows.Clear();
            string player = $"select * \r\nfrom player p\r\njoin team t \r\non t.team_id = p.team_id\r\nwhere team_name = '{cb_team.Text}';";
            sqlCommand = new MySqlCommand(player, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);

            cb_pemain.SelectedIndex = -1;
            cb_pemain.DataSource = dtplayer;
            cb_pemain.ValueMember = "player_id";
            cb_pemain.DisplayMember = "player_name";
            lb_coba.Text = cb_team.SelectedValue.ToString();
        }

        private void cb_pemain_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtmatch.Rows.Clear();
            string player = $"select * \r\nfrom dmatch d\r\njoin player p\r\non d.player_id = p.player_id\r\nwhere player_name = '{cb_pemain.Text}';";
            sqlCommand = new MySqlCommand(player, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtmatch);
        }

        //13.47
        private void btn_add_Click(object sender, EventArgs e)
        {
            dgv_tabel.Columns.Add("M", "Minute");
            dgv_tabel.Columns.Add("T", "Team ID");
            dgv_tabel.Columns.Add("P", "Player ID");
            dgv_tabel.Columns.Add("Ty","Type");

            dgv_tabel.Rows.Add(tb_minute.Text , cb_team.SelectedValue.ToString(), cb_pemain.SelectedValue.ToString(), cb_tipe.SelectedValue.ToString());
            cb_tipe.Text = "";
            cb_team.Text = "";
            cb_pemain.Text = "";
            tb_minute.Text = "";

        }
    }
}
